const bandData = require('./bands');
module.exports = { bands: bandData };